

package rpg;

//import .*;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author jason_yu
 */
public abstract class Role {
    
    private int level;
    private int exp;
    
    private int hp;
    private int mp;
    
    private int str;
    private int dex;
    private int intelligent;
    private int luck;
    
    private int boss_damage;
    private int normal_damage;
    
    private double armor_reduce;
    
    private double crit;
    private double crit_damage;
    
    private int phy_damage;
    private int mag_damage;
    
    private int final_damage;
    
    private  int armour;

    public int getArmour() {
        return armour;
    }

    public void setArmour(int armour) {
        this.armour = armour;
    }

    public int getLevel() {
        return level;
    }

    public void setLevel(int level) {
        this.level = level;
    }

    public int getExp() {
        return exp;
    }

    public void setExp(int exp) {
        this.exp = exp;
    }

    public int getHp() {
        return hp;
    }

    public void setHp(int hp) {
        this.hp = hp;
    }

    public int getMp() {
        return mp;
    }

    public void setMp(int mp) {
        this.mp = mp;
    }

    public int getStr() {
        return str;
    }

    public void setStr(int str) {
        this.str = str;
    }

    public int getDex() {
        return dex;
    }

    public void setDex(int dex) {
        this.dex = dex;
    }

    public int getIntelligent() {
        return intelligent;
    }

    public void setIntelligent(int intelligent) {
        this.intelligent = intelligent;
    }

    public int getLuck() {
        return luck;
    }

    public void setLuck(int luck) {
        this.luck = luck;
    }

    public int getBoss_damage() {
        return boss_damage;
    }

    public void setBoss_damage(int boss_damage) {
        this.boss_damage = boss_damage;
    }

    public int getNormal_damage() {
        return normal_damage;
    }

    public void setNormal_damage(int normal_damage) {
        this.normal_damage = normal_damage;
    }

    public double getArmor_reduce() {
        return armor_reduce;
    }

    public void setArmor_reduce(double armor_reduce) {
        this.armor_reduce = armor_reduce;
    }

    public double getCrit() {
        return crit;
    }

    public void setCrit(double crit) {
        this.crit = crit;
    }

    public double getCrit_damage() {
        return crit_damage;
    }

    public void setCrit_damage(double crit_damage) {
        this.crit_damage = crit_damage;
    }

    public int getPhy_damage() {
        return phy_damage;
    }

    public void setPhy_damage(int phy_damage) {
        this.phy_damage = phy_damage;
    }

    public int getMag_damage() {
        return mag_damage;
    }

    public void setMag_damage(int mag_damage) {
        this.mag_damage = mag_damage;
    }

    public int getFinal_damage() {
        return final_damage;
    }

    public void setFinal_damage(int final_damage) {
        this.final_damage = final_damage;
    }
    
}
