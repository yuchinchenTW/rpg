/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rpg;

import java.util.Random;

/**
 *
 * @author jason_yu
 */
public abstract class Dice {
    
    public int rangeRan(int  range){
        if(range<0){
           range=0;
        }
        int result=0;
        Random ran = new Random();
        result=ran.nextInt(range-0);
        if(result<0){
            result=0;
        }
        return result;
    }
    
    
}
