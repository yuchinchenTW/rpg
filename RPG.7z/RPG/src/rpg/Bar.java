/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rpg;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

/**
 *
 * @author jason_yu
 */
public class Bar implements MouseListener, ActionListener, WindowListener, KeyListener {

	private JFrame frame;

	private JLabel label;
	private JPanel toptoppanel;
	private JPanel toppanel;
	private Database database;
	private JLabel result;

	Bar() throws SQLException {
		database = new Database("RPG", "JASON");
		this.database.setSchema("RPG");

		this.label = new JLabel();
		label.setLayout(null);
		label.setSize(300, 30);
		label.setVisible(true);
		label.setLocation(400, 0);

		this.toptoppanel = new JPanel();
		this.toptoppanel.setLayout(null);
		this.toptoppanel.setVisible(true);
		this.toptoppanel.setSize(1000, 100);
		this.toptoppanel.setLocation(0, 0);
		this.toptoppanel.add(label);

		toppanel = new JPanel();
		toppanel.setSize(1000, 50);
		this.toppanel.setVisible(true);
		// this.toppanel.setBackground(Color.red);
		this.toppanel.setLocation(0, 100);

		frame = new JFrame("bar");
		frame.getContentPane().setLayout(null);

		JLabel label1 = new JLabel("a");
		label1.setBounds(10, 10, 148, 357);
		frame.getContentPane().add(label1);

		JLabel label2 = new JLabel("b");
		label2.setBounds(168, 10, 148, 357);
		frame.getContentPane().add(label2);

		JLabel label3 = new JLabel("c");
		label3.setBounds(332, 10, 148, 357);
		frame.getContentPane().add(label3);

		JLabel label4 = new JLabel("d");
		label4.setBounds(509, 10, 148, 357);
		frame.getContentPane().add(label4);

		JLabel label5 = new JLabel("e");
		label5.setBounds(677, 10, 148, 357);
		frame.getContentPane().add(label5);

		JButton character_dice = new JButton("dice");
		character_dice.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {

			}
		});
		character_dice.setBounds(168, 443, 87, 23);
		frame.getContentPane().add(character_dice);

		JButton resurrect_button = new JButton("resurrect");
		resurrect_button.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {

			}
		});
		resurrect_button.setBounds(416, 443, 87, 23);
		frame.getContentPane().add(resurrect_button);
	
		JLabel lab_lab = new JLabel("a");
		lab_lab.setBounds(75, 308, 46, 15);
		frame.getContentPane().add(lab_lab);
		frame.setSize(1000, 800);
		frame.setVisible(true);

		this.frame.addWindowListener(this);

	}

	@Override
	public void mouseClicked(MouseEvent e) {
	}

	@Override
	public void mousePressed(MouseEvent e) {
	}

	@Override
	public void mouseReleased(MouseEvent e) {
	}

	@Override
	public void mouseEntered(MouseEvent e) {
	}

	@Override
	public void mouseExited(MouseEvent e) {
	}

	@Override
	public void actionPerformed(ActionEvent e) {
	}

	@Override
	public void windowOpened(WindowEvent e) {
	}

	@Override
	public void windowClosing(WindowEvent e) {
		System.exit(0); // To change body of generated methods, choose Tools | Templates.
	}

	@Override
	public void windowClosed(WindowEvent e) {
		System.exit(0); // To change body of generated methods, choose Tools | Templates.
	}

	@Override
	public void windowIconified(WindowEvent e) {

	}

	@Override
	public void windowDeiconified(WindowEvent e) {
	}

	@Override
	public void windowActivated(WindowEvent e) {
	}

	@Override
	public void windowDeactivated(WindowEvent e) {
	}

	@Override
	public void keyTyped(KeyEvent e) {
		throw new UnsupportedOperationException("Not supported yet."); // To change body of generated methods, choose
		// Tools | Templates.
	}

	@Override
	public void keyPressed(KeyEvent e) {
		throw new UnsupportedOperationException("Not supported yet."); // To change body of generated methods, choose
		// Tools | Templates.
	}

	@Override
	public void keyReleased(KeyEvent e) {
		throw new UnsupportedOperationException("Not supported yet."); // To change body of generated methods, choose
		// Tools | Templates.
	}
}
