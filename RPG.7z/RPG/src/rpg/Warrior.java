/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rpg;

/**
 *
 * @author jason_yu
 */
public class Warrior extends Role{
    Warrior(){
        
        
    }

    @Override
    public void setHp(int hp) {
        super.setHp(hp); //To change body of generated methods, choose Tools | Templates.
    }
    

    @Override
    public void setFinal_damage(int final_damage) {
        super.setFinal_damage(final_damage); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int getFinal_damage() {
        return super.getFinal_damage(); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void setMag_damage(int mag_damage) {
        super.setMag_damage(mag_damage); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int getMag_damage() {
        return super.getMag_damage(); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void setPhy_damage(int phy_damage) {
        super.setPhy_damage(phy_damage); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int getPhy_damage() {
        return super.getPhy_damage(); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void setCrit_damage(double crit_damage) {
        super.setCrit_damage(crit_damage); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public double getCrit_damage() {
        return super.getCrit_damage(); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void setCrit(double crit) {
        super.setCrit(crit); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public double getCrit() {
        return super.getCrit(); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void setArmor_reduce(double armor_reduce) {
        super.setArmor_reduce(armor_reduce); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public double getArmor_reduce() {
        return super.getArmor_reduce(); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void setNormal_damage(int normal_damage) {
        super.setNormal_damage(normal_damage); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int getNormal_damage() {
        return super.getNormal_damage(); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void setBoss_damage(int boss_damage) {
        super.setBoss_damage(boss_damage); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int getBoss_damage() {
        return super.getBoss_damage(); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void setLuck(int luck) {
        super.setLuck(luck); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int getLuck() {
        return super.getLuck(); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void setIntelligent(int intelligent) {
        super.setIntelligent(intelligent); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int getIntelligent() {
        return super.getIntelligent(); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void setDex(int dex) {
        super.setDex(dex); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int getDex() {
        return super.getDex(); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void setStr(int str) {
        super.setStr(str); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int getStr() {
        return super.getStr(); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void setMp(int mp) {
        super.setMp(mp); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int getMp() {
        return super.getMp(); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int getHp() {
        return super.getHp(); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void setExp(int exp) {
        super.setExp(exp); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int getExp() {
        return super.getExp(); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void setLevel(int level) {
        super.setLevel(level); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int getLevel() {
        return super.getLevel(); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void setArmour(int armour) {
        super.setArmour(armour); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int getArmour() {
        return super.getArmour(); //To change body of generated methods, choose Tools | Templates.
    }
    
}
