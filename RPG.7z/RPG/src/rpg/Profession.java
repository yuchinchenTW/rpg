/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rpg;

/**
 *
 * @author jason_yu
 */
public class Profession {
    enum proferssion{warrior,archer,mage,rogue};
    String profession;
    Ability ability;
    Profession(String pro){
        this.profession=pro;
        
        
        
    }
    
    
    void set_Ability(String pro){
        switch(pro){
            case "warrior":
                
            case"archer":
            
            case"mage":
            
            case"rogue":
        
        }
                
            
        
    }
}
