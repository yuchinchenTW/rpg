/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rpg;

//import java.applet.Applet;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

/**
 *
 * @author jason_yu
 */
public class Game  implements MouseListener, ActionListener, WindowListener, KeyListener{
    
    private JFrame frame;
	private JTextField usrName;
	private JLabel label;
	private JPanel toptoppanel;
	private JPanel toppanel;
	private JTextArea ID;
	private JLabel result;
    Game(){
      
		this.label = new JLabel();
		label.setLayout(null);
		label.setSize(300, 30);
		label.setVisible(true);
		label.setLocation(400, 0);

		this.toptoppanel = new JPanel();
		this.toptoppanel.setLayout(null);
		this.toptoppanel.setVisible(true);
		this.toptoppanel.setSize(1000, 100);
		this.toptoppanel.setLocation(0, 0);
		this.toptoppanel.add(label);

		toppanel = new JPanel();
		toppanel.setSize(1000, 50);
		this.toppanel.setVisible(true);
		// this.toppanel.setBackground(Color.red);
		this.toppanel.setLocation(0, 100);

		frame = new JFrame("Game");
		frame.getContentPane().setLayout(null);

		JButton dIce = new JButton("POTENTIAL");
		dIce.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
                    Potential p = new Potential();
                } catch (SQLException ex) {
                    Logger.getLogger(Game.class.getName()).log(Level.SEVERE, null, ex);
                }

			}
		});
		dIce.setBounds(433, 523, 109, 23);
		frame.getContentPane().add(dIce);
		
		JButton BAR = new JButton("BAR");
		BAR.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
                            try {
								Bar bar =new Bar();
							} catch (SQLException e1) {
								// TODO Auto-generated catch block
								e1.printStackTrace();
							}
			}
		});
		BAR.setBounds(587, 523, 87, 23);
		frame.getContentPane().add(BAR);
		frame.setSize(1000, 800);
		frame.setVisible(true);

		this.frame.addWindowListener(this);

    }
    
    	@Override
	public void mouseClicked(MouseEvent e) {
	}

	@Override
	public void mousePressed(MouseEvent e) {
	}

	@Override
	public void mouseReleased(MouseEvent e) {
	}

	@Override
	public void mouseEntered(MouseEvent e) {
	}

	@Override
	public void mouseExited(MouseEvent e) {
	}

	@Override
	public void actionPerformed(ActionEvent e) {
	}

	@Override
	public void windowOpened(WindowEvent e) {
	}

	@Override
	public void windowClosing(WindowEvent e) {
		System.exit(0); // To change body of generated methods, choose Tools | Templates.
	}

	@Override
	public void windowClosed(WindowEvent e) {
		System.exit(0); // To change body of generated methods, choose Tools | Templates.
	}

	@Override
	public void windowIconified(WindowEvent e) {

	}

	@Override
	public void windowDeiconified(WindowEvent e) {
	}

	@Override
	public void windowActivated(WindowEvent e) {
	}

	@Override
	public void windowDeactivated(WindowEvent e) {
	}

	@Override
	public void keyTyped(KeyEvent e) {
		throw new UnsupportedOperationException("Not supported yet."); // To change body of generated methods, choose
																		// Tools | Templates.
	}

	@Override
	public void keyPressed(KeyEvent e) {
		throw new UnsupportedOperationException("Not supported yet."); // To change body of generated methods, choose
																		// Tools | Templates.
	}

	@Override
	public void keyReleased(KeyEvent e) {
		throw new UnsupportedOperationException("Not supported yet."); // To change body of generated methods, choose
																		// Tools | Templates.
	}
    
}
