/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rpg;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

/**
 *
 * @author jason_yu
 */
public class Potential extends Dice implements MouseListener, ActionListener, WindowListener, KeyListener {

    private JFrame frame;
    private JTextField usrName;
    private JLabel label;
    private JPanel toptoppanel;
    private JPanel toppanel;
    private JTextArea ID;
    private JLabel result;
    private JTextArea OUTPUT;
    private final int max_checkbox = 4;
    private int current_checkbox = 0;
    private Database database;
    private JCheckBox B1, B2, B3, B4, B5, B6, B7, B8, B9, B10, B11, B12;
    private ArrayList<Integer> list_integer;
    private JComboBox CHOOSEITEM;
    private String[] split_columnout;
    private int select_index;
    Potential() throws SQLException {
        database = new Database("RPG", "JASON");
        this.database.setSchema("RPG");
        this.label = new JLabel();
        label.setLayout(null);
        label.setSize(300, 30);
        label.setVisible(true);
        label.setLocation(400, 0);

        this.toptoppanel = new JPanel();
        this.toptoppanel.setLayout(null);
        this.toptoppanel.setVisible(true);
        this.toptoppanel.setSize(1000, 100);
        this.toptoppanel.setLocation(0, 0);
        this.toptoppanel.add(label);

        toppanel = new JPanel();
        toppanel.setSize(1000, 50);
        this.toppanel.setVisible(true);
        // this.toppanel.setBackground(Color.red);
        this.toppanel.setLocation(0, 100);

        frame = new JFrame("Game");
        frame.getContentPane().setLayout(null);

        JButton dIce = new JButton("Dice");
        
        list_integer = new ArrayList<Integer>();
        dIce.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                
                
                if(current_checkbox==4){
                        
                        recognize_choosing();
                        checkbox_action();
                    
                    
                }
                list_integer.clear();
                checkbox_unable();
                current_checkbox = 0;
                
                Random ran = new Random();
                boolean loop = true;
                ArrayList<String> list;
               
                list = new ArrayList<String>();
                 database.showIndexMax("CLOTH", "INDEX");
                int max_index= Integer.parseInt(database.output());
                for(int i=0;i<12;i++){
                    int a = ran.nextInt(max_index) + 1;
                    list_integer.add(a);
                    Collections.sort(list_integer);
                    
                }
                Collections.sort(list_integer);
                   //  Collections.sort(list_integer);
                   for(int i=0;i<12;i++){
                    String out[];
                    String fin = "";
                    try {
                        database.searchIndex("CLOTH", "INDEX", String.valueOf(list_integer.get(i)));
                        out = database.output().split("\\|");
                        if (Integer.parseInt(out[2]) == 0) {
                            fin = out[1] + " " + out[3] + "%";
                        } else if (Integer.parseInt(out[3]) == 0) {
                            fin = out[1] + " " + out[2];
                        }
                    } catch (SQLException ex) {
                        Logger.getLogger(Potential.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    // if(list.contains(a)==false){
                    //String fin = out[0]+" "+out[1]+" "+out[2];
                    list.add(fin);
                   }
          //      Collections.sort(list); 
                B1.setText(String.valueOf(list.get(0)));
                B2.setText(String.valueOf(list.get(1)));
                B3.setText(String.valueOf(list.get(2)));
                B4.setText(String.valueOf(list.get(3)));
                B5.setText(String.valueOf(list.get(4)));
                B6.setText(String.valueOf(list.get(5)));
                B7.setText(String.valueOf(list.get(6)));
                B8.setText(String.valueOf(list.get(7)));
                B9.setText(String.valueOf(list.get(8)));
                B10.setText(String.valueOf(list.get(9)));
                B11.setText(String.valueOf(list.get(10)));
                B12.setText(String.valueOf(list.get(11)));
                list.clear();
               // database.shutDown();;

            }
        });
        dIce.setBounds(433, 523, 87, 23);
        frame.getContentPane().add(dIce);

        CHOOSEITEM = new JComboBox();
        CHOOSEITEM.setBounds(133, 47, 174, 23);
        CHOOSEITEM.addItem("drag down");
        CHOOSEITEM.setSelectedIndex(0);
        this.database.showColumnContent("ITEM", "ITEM_NAME");
        String column_out = this.database.output();
        split_columnout = column_out.split("\n");
        for (int i = 0; i < split_columnout.length; i++) {
            CHOOSEITEM.addItem(split_columnout[i]);
        }
        CHOOSEITEM.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                //String b=String.valueOf(CHOOSEITEM.getSelectedItem());
                select_index = CHOOSEITEM.getSelectedIndex();
                try {
                    OUTPUT.setText("");
                    database.getTableColumnOnly("ITEM_DEFAULT");
                    String column[] = database.output().split("\\|");
                    //   System.out.println(column.length);
                    database.searchIndex("ITEM_DEFAULT", "IDCLASS", Integer.toString(select_index));
                    String output[] = database.output().split("\\|");
                    //     System.out.println("out:"+output.length);
                    String out = "";
                    for (int i = 0; i < output.length; i++) {
                        if (i < 17) {
                            String terminate = column[i] + ":" + output[i] + "\n";

                            out = out + terminate;
                        } else if (i >= 17) {
                            String terminate ="";
                            try {
                                String t="";
                                database.searchbetween("CLOTH", "ABILITY", "INDEX", Integer.parseInt(output[i]), Integer.parseInt(output[i]));
                                String split_com_v[]= database.output().split("\\|");
                                //String ter = column[i] + ":"+split_com[0]+ "\n";
                                database.searchbetween("CLOTH", "VALUE", "INDEX", Integer.parseInt(output[i]), Integer.parseInt(output[i]));
                               
                                String split_com[] = database.output().split("\\|");
                                //String ter = column[i] + ":"+split_com[0]+ "\n";
                        
                                if (Integer.parseInt(split_com[0]) == 0) {
                                database.searchbetween("CLOTH", "PERCENTAGE", "INDEX", Integer.parseInt(output[i]), Integer.parseInt(output[i]));
                               String plit_com_var[] = database.output().split("\\|");
                               String ter_v = column[i] + ":"+split_com_v[0]+" "+plit_com_var[0]+"%"+ "\n";
                               out = out + ter_v;
                                }else if(Integer.parseInt(split_com[0]) != 0){
                                    t = column[i] + ":"+split_com_v[0]+" "+split_com[0]+ "\n";
                                     out = out + t;
                                }
                                //  System.out.println(database.output());
                            } catch (InterruptedException ex) {
                                Logger.getLogger(Potential.class.getName()).log(Level.SEVERE, null, ex);
                            }
                        }
                    }
                    OUTPUT.setText(out);

                } catch (SQLException ex) {
                    Logger.getLogger(Potential.class.getName()).log(Level.SEVERE, null, ex);
                }

            }
        });
        //CHOOSEITEM.removeAllItems();
        frame.getContentPane().add(CHOOSEITEM);

        JLabel lblNewLabel = new JLabel("select");
        lblNewLabel.setBounds(24, 42, 74, 33);
        frame.getContentPane().add(lblNewLabel);

        JScrollPane scrollPane = new JScrollPane();
        scrollPane.setBounds(56, 124, 174, 276);
        frame.getContentPane().add(scrollPane);

        OUTPUT = new JTextArea();
        scrollPane.setViewportView(OUTPUT);
        OUTPUT.setColumns(10);

        JLabel answer = new JLabel("result");
        answer.setBounds(328, 367, 154, 33);
        frame.getContentPane().add(answer);

        B1 = new JCheckBox("B1");
        B1.setBounds(498, 31, 200, 23);
        B1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (current_checkbox >= 4) {
                    if (B1.isSelected() == true) {
                        B1.setSelected(false);
                    } else if ((B1.isSelected() == false)) {
                        current_checkbox--;
                        if (current_checkbox < 0) {
                            current_checkbox = 0;
                        }
                    }
                } else if (current_checkbox <= 3) {
                    if (B1.isSelected() == true) {
                        current_checkbox++;
                    } else if ((B1.isSelected() == false)) {
                        current_checkbox--;
                        if (current_checkbox < 0) {
                            current_checkbox = 0;
                        }
                    }

                }
            }
        });
        frame.getContentPane().add(B1);

        B2 = new JCheckBox("B2");
        B2.setBounds(498, 56, 200, 23);
        B2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (current_checkbox >= 4) {
                    if (B2.isSelected() == true) {
                        B2.setSelected(false);
                    } else if ((B2.isSelected() == false)) {
                        current_checkbox--;
                        if (current_checkbox < 0) {
                            current_checkbox = 0;
                        }
                    }
                } else if (current_checkbox <= 3) {
                    if (B2.isSelected() == true) {
                        current_checkbox++;
                    } else if ((B2.isSelected() == false)) {
                        current_checkbox--;
                        if (current_checkbox < 0) {
                            current_checkbox = 0;
                        }
                    }

                }
            }
        });
        frame.getContentPane().add(B2);

        B3 = new JCheckBox("B3");
        B3.setBounds(498, 81, 200, 23);
        B3.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (current_checkbox >= 4) {
                    if (B3.isSelected() == true) {
                        B3.setSelected(false);
                    } else if ((B3.isSelected() == false)) {
                        current_checkbox--;
                        if (current_checkbox < 0) {
                            current_checkbox = 0;
                        }
                    }
                } else if (current_checkbox <= 3) {
                    if (B3.isSelected() == true) {
                        current_checkbox++;
                    } else if ((B3.isSelected() == false)) {
                        current_checkbox--;
                        if (current_checkbox < 0) {
                            current_checkbox = 0;
                        }
                    }

                }
            }
        });
        frame.getContentPane().add(B3);

        B4 = new JCheckBox("B4");
        B4.setBounds(498, 106, 200, 23);
        B4.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (current_checkbox >= 4) {
                    if (B4.isSelected() == true) {
                        B4.setSelected(false);
                    } else if ((B4.isSelected() == false)) {
                        current_checkbox--;
                        if (current_checkbox < 0) {
                            current_checkbox = 0;
                        }
                    }
                } else if (current_checkbox <= 3) {
                    if (B4.isSelected() == true) {
                        current_checkbox++;
                    } else if ((B4.isSelected() == false)) {
                        current_checkbox--;
                        if (current_checkbox < 0) {
                            current_checkbox = 0;
                        }
                    }

                }
            }
        });
        frame.getContentPane().add(B4);

        B5 = new JCheckBox("B5");
        B5.setBounds(498, 131, 200, 23);
        B5.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (current_checkbox >= 4) {
                    if (B5.isSelected() == true) {
                        B5.setSelected(false);
                    } else if ((B5.isSelected() == false)) {
                        current_checkbox--;
                        if (current_checkbox < 0) {
                            current_checkbox = 0;
                        }
                    }
                } else if (current_checkbox <= 3) {
                    if (B5.isSelected() == true) {
                        current_checkbox++;
                    } else if ((B5.isSelected() == false)) {
                        current_checkbox--;
                        if (current_checkbox < 0) {
                            current_checkbox = 0;
                        }
                    }

                }
            }
        });
        frame.getContentPane().add(B5);

        B6 = new JCheckBox("B6");
        B6.setBounds(498, 156, 200, 23);
        B6.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (current_checkbox >= 4) {
                    if (B6.isSelected() == true) {
                        B6.setSelected(false);
                    } else if ((B6.isSelected() == false)) {
                        current_checkbox--;
                        if (current_checkbox < 0) {
                            current_checkbox = 0;
                        }
                    }
                } else if (current_checkbox <= 3) {
                    if (B6.isSelected() == true) {
                        current_checkbox++;
                    } else if ((B6.isSelected() == false)) {
                        current_checkbox--;
                        if (current_checkbox < 0) {
                            current_checkbox = 0;
                        }
                    }

                }
            }
        });
        frame.getContentPane().add(B6);

        B7 = new JCheckBox("B7");
        B7.setBounds(498, 181, 200, 23);
        B7.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (current_checkbox >= 4) {
                    if (B7.isSelected() == true) {
                        B7.setSelected(false);
                    } else if ((B7.isSelected() == false)) {
                        current_checkbox--;
                        if (current_checkbox < 0) {
                            current_checkbox = 0;
                        }
                    }
                } else if (current_checkbox <= 3) {
                    if (B7.isSelected() == true) {
                        current_checkbox++;
                    } else if ((B7.isSelected() == false)) {
                        current_checkbox--;
                        if (current_checkbox < 0) {
                            current_checkbox = 0;
                        }
                    }

                }
            }
        });
        frame.getContentPane().add(B7);

        B8 = new JCheckBox("B8");
        B8.setBounds(498, 207, 200, 23);
        B8.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (current_checkbox >= 4) {
                    if (B8.isSelected() == true) {
                        B8.setSelected(false);
                    } else if ((B8.isSelected() == false)) {
                        current_checkbox--;
                        if (current_checkbox < 0) {
                            current_checkbox = 0;
                        }
                    }
                } else if (current_checkbox <= 3) {
                    if (B8.isSelected() == true) {
                        current_checkbox++;
                    } else if ((B8.isSelected() == false)) {
                        current_checkbox--;
                        if (current_checkbox < 0) {
                            current_checkbox = 0;
                        }
                    }

                }
            }
        });
        frame.getContentPane().add(B8);

        B9 = new JCheckBox("B9");
        B9.setBounds(498, 232, 200, 23);
        B9.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (current_checkbox >= 4) {
                    if (B9.isSelected() == true) {
                        B9.setSelected(false);
                    } else if ((B9.isSelected() == false)) {
                        current_checkbox--;
                        if (current_checkbox < 0) {
                            current_checkbox = 0;
                        }
                    }
                } else if (current_checkbox <= 3) {
                    if (B9.isSelected() == true) {
                        current_checkbox++;
                    } else if ((B9.isSelected() == false)) {
                        current_checkbox--;
                        if (current_checkbox < 0) {
                            current_checkbox = 0;
                        }
                    }

                }
            }
        });
        frame.getContentPane().add(B9);

        B10 = new JCheckBox("B10");
        B10.setBounds(498, 257, 200, 23);
        B10.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (current_checkbox >= 4) {
                    if (B10.isSelected() == true) {
                        B10.setSelected(false);
                    } else if ((B10.isSelected() == false)) {
                        current_checkbox--;
                        if (current_checkbox < 0) {
                            current_checkbox = 0;
                        }
                    }
                } else if (current_checkbox <= 3) {
                    if (B10.isSelected() == true) {
                        current_checkbox++;
                    } else if ((B10.isSelected() == false)) {
                        current_checkbox--;
                        if (current_checkbox < 0) {
                            current_checkbox = 0;
                        }
                    }

                }
            }
        });
        frame.getContentPane().add(B10);

        B12 = new JCheckBox("B12");
        B12.setBounds(498, 308, 200, 23);
        B12.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (current_checkbox >= 4) {
                    if (B12.isSelected() == true) {
                        B12.setSelected(false);
                    } else if ((B12.isSelected() == false)) {
                        current_checkbox--;
                        if (current_checkbox < 0) {
                            current_checkbox = 0;
                        }
                    }
                } else if (current_checkbox <= 3) {
                    if (B12.isSelected() == true) {
                        current_checkbox++;
                    } else if ((B12.isSelected() == false)) {
                        current_checkbox--;
                        if (current_checkbox < 0) {
                            current_checkbox = 0;
                        }
                    }

                }
            }
        });
        frame.getContentPane().add(B12);

        B11 = new JCheckBox("B11");
        B11.setBounds(498, 282, 200, 23);
        B11.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (current_checkbox >= 4) {
                    if (B11.isSelected() == true) {
                        B11.setSelected(false);
                    } else if ((B11.isSelected() == false)) {
                        current_checkbox--;
                        if (current_checkbox < 0) {
                            current_checkbox = 0;
                        }
                    }
                } else if (current_checkbox <= 3) {
                    if (B11.isSelected() == true) {
                        current_checkbox++;
                    } else if ((B11.isSelected() == false)) {
                        current_checkbox--;
                        if (current_checkbox < 0) {
                            current_checkbox = 0;
                        }
                    }

                }
            }
        });
        frame.getContentPane().add(B11);
        frame.setSize(1000, 800);
        frame.setVisible(true);

        this.frame.addWindowListener(this);

    }

    @Override
    public void mouseClicked(MouseEvent e) {
    }

    @Override
    public void mousePressed(MouseEvent e) {
    }

    @Override
    public void mouseReleased(MouseEvent e) {
    }

    @Override
    public void mouseEntered(MouseEvent e) {
    }

    @Override
    public void mouseExited(MouseEvent e) {
    }

    @Override
    public void actionPerformed(ActionEvent e) {
    }

    @Override
    public void windowOpened(WindowEvent e) {
    }

    @Override
    public void windowClosing(WindowEvent e) {
       //
       database.shutDown();
    }

    @Override
    public void windowClosed(WindowEvent e) {
        database.shutDown();
        frame.dispatchEvent(new WindowEvent(frame, WindowEvent.WINDOW_CLOSING));
    }

    @Override
    public void windowIconified(WindowEvent e) {

    }

    @Override
    public void windowDeiconified(WindowEvent e) {
    }

    @Override
    public void windowActivated(WindowEvent e) {
    }

    @Override
    public void windowDeactivated(WindowEvent e) {
    }

    @Override
    public void keyTyped(KeyEvent e) {
        throw new UnsupportedOperationException("Not supported yet."); // To change body of generated methods, choose
        // Tools | Templates.
    }

    @Override
    public void keyPressed(KeyEvent e) {
        throw new UnsupportedOperationException("Not supported yet."); // To change body of generated methods, choose
        // Tools | Templates.
    }

    @Override
    public void keyReleased(KeyEvent e) {
        throw new UnsupportedOperationException("Not supported yet."); // To change body of generated methods, choose
        // Tools | Templates.
    }
    
    private void checkbox_unable(){
        B1.setSelected(false);
        B2.setSelected(false);
        B3.setSelected(false);
        B4.setSelected(false);
        B5.setSelected(false);
        B6.setSelected(false);
        B7.setSelected(false);
        B8.setSelected(false);
        B9.setSelected(false);
        B10.setSelected(false);
        B11.setSelected(false);
        B12.setSelected(false);
    }
    
    private ArrayList<Integer> recognize_choosing(){
        ArrayList<Integer> list;
        list= new ArrayList<Integer>();
        int count=0;
        select_index = CHOOSEITEM.getSelectedIndex();
        String index=String.valueOf(this.select_index);
        String column[]={"POT1","POT2","POT3","POT4"};
       // Collections.sort(list_integer);
        if(B1.isSelected()==true){
            try {
                database.changeTableTargetcontent("ITEM_DEFAULT",index , column[count], String.valueOf(list_integer.get(0)));
                count++;
            } catch (SQLException ex) {
                Logger.getLogger(Potential.class.getName()).log(Level.SEVERE, null, ex);
            }
            
        }
        if(B2.isSelected()==true){
              try {
                database.changeTableTargetcontent("ITEM_DEFAULT",index , column[count], String.valueOf(list_integer.get(1)));
                count++;
            } catch (SQLException ex) {
                Logger.getLogger(Potential.class.getName()).log(Level.SEVERE, null, ex);
            }
            
        }
        if(B3.isSelected()==true){
              try {
                database.changeTableTargetcontent("ITEM_DEFAULT",index , column[count], String.valueOf(list_integer.get(2)));
                count++;
            } catch (SQLException ex) {
                Logger.getLogger(Potential.class.getName()).log(Level.SEVERE, null, ex);
            }
            
        }
        if(B4.isSelected()==true){
              try {
                database.changeTableTargetcontent("ITEM_DEFAULT",index , column[count], String.valueOf(list_integer.get(3)));
                count++;
            } catch (SQLException ex) {
                Logger.getLogger(Potential.class.getName()).log(Level.SEVERE, null, ex);
            }
            
        }
        if(B5.isSelected()==true){
              try {
                database.changeTableTargetcontent("ITEM_DEFAULT",index , column[count], String.valueOf(list_integer.get(4)));
                count++;
            } catch (SQLException ex) {
                Logger.getLogger(Potential.class.getName()).log(Level.SEVERE, null, ex);
            }
            
        }
        if(B6.isSelected()==true){
              try {
                database.changeTableTargetcontent("ITEM_DEFAULT",index , column[count], String.valueOf(list_integer.get(5)));
                count++;
            } catch (SQLException ex) {
                Logger.getLogger(Potential.class.getName()).log(Level.SEVERE, null, ex);
            }
            
        }
        if(B7.isSelected()==true){
              try {
                database.changeTableTargetcontent("ITEM_DEFAULT",index , column[count], String.valueOf(list_integer.get(6)));
                count++;
            } catch (SQLException ex) {
                Logger.getLogger(Potential.class.getName()).log(Level.SEVERE, null, ex);
            }
            
        }
        if(B8.isSelected()==true){
              try {
                database.changeTableTargetcontent("ITEM_DEFAULT",index , column[count], String.valueOf(list_integer.get(7)));
                count++;
            } catch (SQLException ex) {
                Logger.getLogger(Potential.class.getName()).log(Level.SEVERE, null, ex);
            }
            
        }
        if(B9.isSelected()==true){
              try {
                database.changeTableTargetcontent("ITEM_DEFAULT",index , column[count], String.valueOf(list_integer.get(8)));
                count++;
            } catch (SQLException ex) {
                Logger.getLogger(Potential.class.getName()).log(Level.SEVERE, null, ex);
            }
            
        }
        if(B10.isSelected()==true){
              try {
                database.changeTableTargetcontent("ITEM_DEFAULT",index , column[count], String.valueOf(list_integer.get(9)));
                count++;
            } catch (SQLException ex) {
                Logger.getLogger(Potential.class.getName()).log(Level.SEVERE, null, ex);
            }
            
        }
        if(B11.isSelected()==true){
              try {
                database.changeTableTargetcontent("ITEM_DEFAULT",index , column[count], String.valueOf(list_integer.get(10)));
                count++;
            } catch (SQLException ex) {
                Logger.getLogger(Potential.class.getName()).log(Level.SEVERE, null, ex);
            }
            
        }
        if(B12.isSelected()==true){
              try {
                database.changeTableTargetcontent("ITEM_DEFAULT",index , column[count], String.valueOf(list_integer.get(11)));
                count++;
            } catch (SQLException ex) {
                Logger.getLogger(Potential.class.getName()).log(Level.SEVERE, null, ex);
            }
            
        }
        
        return list;
    }
    
    private void checkbox_action(){
        int index = CHOOSEITEM.getSelectedIndex();
                try {
                    OUTPUT.setText("");
                    database.getTableColumnOnly("ITEM_DEFAULT");
                    String column[] = database.output().split("\\|");
                    //   System.out.println(column.length);
                    database.searchIndex("ITEM_DEFAULT", "IDCLASS", Integer.toString(index));
                    String output[] = database.output().split("\\|");
                    //     System.out.println("out:"+output.length);
                    String out = "";
                    for (int i = 0; i < output.length; i++) {
                        if (i < 17) {
                            String terminate = column[i] + ":" + output[i] + "\n";

                            out = out + terminate;
                        } else if (i >= 17) {
                            String terminate ="";
                            try {
                                String t="";
                                database.searchbetween("CLOTH", "ABILITY", "INDEX", Integer.parseInt(output[i]), Integer.parseInt(output[i]));
                                String split_com_v[]= database.output().split("\\|");
                                //String ter = column[i] + ":"+split_com[0]+ "\n";
                                database.searchbetween("CLOTH", "VALUE", "INDEX", Integer.parseInt(output[i]), Integer.parseInt(output[i]));
                               
                                String split_com[] = database.output().split("\\|");
                                //String ter = column[i] + ":"+split_com[0]+ "\n";
                        
                                if (Integer.parseInt(split_com[0]) == 0) {
                                database.searchbetween("CLOTH", "PERCENTAGE", "INDEX", Integer.parseInt(output[i]), Integer.parseInt(output[i]));
                               String plit_com_var[] = database.output().split("\\|");
                               String ter_v = column[i] + ":"+split_com_v[0]+" "+plit_com_var[0]+"%"+ "\n";
                               out = out + ter_v;
                                }else if(Integer.parseInt(split_com[0]) != 0){
                                    t = column[i] + ":"+split_com_v[0]+" "+split_com[0]+ "\n";
                                     out = out + t;
                                }
                                //  System.out.println(database.output());
                            } catch (InterruptedException ex) {
                                Logger.getLogger(Potential.class.getName()).log(Level.SEVERE, null, ex);
                            }
                        }
                    }
                    OUTPUT.setText(out);

                } catch (SQLException ex) {
                    Logger.getLogger(Potential.class.getName()).log(Level.SEVERE, null, ex);
                }
    }
}

class TestProgram {

    public static JCheckBox[] checkList = new JCheckBox[10];

    TestProgram(int chackbox_num) {

        Listener listener = new Listener();

        for (int i = 0; i < 10; ++i) {
            checkList[i] = new JCheckBox("CheckBox-" + i);
            checkList[i].addItemListener(listener);
        }

        //
        // The rest of the GUI layout job ...
        //
    }

    static class Listener implements ItemListener {

        private final int MAX_SELECTIONS = 3;

        private int selectionCounter = 0;

        @Override
        public void itemStateChanged(ItemEvent e) {
            JCheckBox source = (JCheckBox) e.getSource();

            if (source.isSelected()) {
                selectionCounter++;
                // check for max selections:
                if (selectionCounter == MAX_SELECTIONS) {
                    for (JCheckBox box : checkList) {
                        if (!box.isSelected()) {
                            box.setEnabled(false);
                        }
                    }
                }
            } else {
                selectionCounter--;
                // check for less than max selections:
                if (selectionCounter < MAX_SELECTIONS) {
                    for (JCheckBox box : checkList) {
                        box.setEnabled(true);
                    }
                }
            }
        }

    }
}
