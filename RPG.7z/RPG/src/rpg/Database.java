/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rpg;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.SQLException;
import java.sql.ResultSetMetaData;
import java.sql.DatabaseMetaData;
import java.sql.*;
//import java.util.ArrayList;
//import java.lang.Runtime;

import java.io.File;

//import java.io.PrintWriter;
//import java.net.InetAddress;
/**
 * The Database class is a class which can create tables,Schemas.It is base on
 * ApacheDerby and can only support the type of String or Integer.The default
 * Schema is always same as user name. If the Schema is not exist,it will create
 * a new Schema by its own and the Schema name is same as user name but in
 * uppercase.
 *
 *
 * @author jason Yu chih chen from taiwan  ming chi university of technology electronic engineering
 */
public class Database {

    private Connection conn = null;
    private Statement stmt = null;
    private String sql = null;
    // private final String dbURL = "jdbc:derby://localhost:1527/home;create=true;user=jason;password=123";
    private String dbURL2 = null;
    private String user = "defaultSchema!";
    private String storemessage = null;
    private String terminate = null;
    private String error = null;

    /**
     * @param args the command line arguments
     * @throws java.sql.SQLException
     * @throws java.lang.InterruptedException
     */
    
    /**
     *
     * @param a
     * @throws InterruptedException
     */
    private Database(int a) throws InterruptedException {
        this.dbURL2 = "jdbc:derby:home;create=true;user=" + user;
        cmdCallserver();
        connect();
    }

    /**
     * Connecting with default user this might cause all table be created in
     * default Schema Notice the default schema is not the regular one(APP) .The
     * default schema is defaultSchema!.
     *
     *
     * @throws InterruptedException
     */
    public Database() throws InterruptedException {
        this.dbURL2 = "jdbc:derby:home;create=true;user=" + textfix(user);

        connect();
    }

    /**
     * Connecting with chosen user this might cause all table be created in
     * chosen Schema which is as same as the user name If the Schema is not
     * exist ,it will create by it own ,when schema is called by method.such as
     * creatTable()
     *
     *
     * @param username user name
     * @throws InterruptedException
     */
    public Database(String username) throws InterruptedException {
        this.dbURL2 = "jdbc:derby:home;create=true;user=" + textfix(username);

        connect();
    }

    /**
     * Connecting with chosen user and database
     *
     * @param DatabaseName
     * @param username
     */
    public Database(String DatabaseName, String username) {
        this.dbURL2 = "jdbc:derby:" + DatabaseName + ";create=true;user=" + textfix(username);

        connect();
    }

    /**
     * Connecting with chosen database the integer input can be random number
     *
     * @param DatabaseName
     * @param a
     */
    public Database(String DatabaseName, int a) {
        this.dbURL2 = "jdbc:derby:" + DatabaseName + ";create=true;user=" + textfix(user);

        connect();
    }

    private void reset() {
        terminate = "";
        storemessage = "";
        error = "";
        sql = "";
    }

    private String textfix(String input) {
        String result = "\"" + input + "\"";
        return result;

    }

    /**
     * Opening the Derby server which can allow the connection to the Apache
     * Derby. The method is base on Windows Run with cmd command.
     *
     * @throws InterruptedException
     */
    private void cmdCallserver() throws InterruptedException {
        reset();
        File directory = new File("");
        String previouspath = directory.getAbsolutePath();
        System.out.println(previouspath);
        String fix = "\\dist\\lib\\";
        String correction = previouspath + fix;
        //ystem.out.println(correction);
        // Runtime cmd = new Runtime();
        try {

            String command = "java -jar " + correction + "derbyrun.jar server start";

            //Process rt=Runtime.getRuntime().exec(cmdArray);
            Process rt = Runtime.getRuntime().exec("cmd /k start " + command);
           
            // System.out.println("done");
            Thread.sleep(1000);
        } catch (Exception e) {

        }

    }

    /**
     * Create connection to the Apache Derby.
     *
     */
    private void connect() {
        reset();
        try {
            // String driver = "org.apache.derby.jdbc.ClientDriver";
            String driver2 = "org.apache.derby.jdbc.EmbeddedDriver";
            Class.forName(driver2).newInstance();
            conn = DriverManager.getConnection(dbURL2);
        
            //  System.out.println("Connection confirm");

        } catch (Exception e) {
            String Exceptioninput = e.toString();
            String Exceptionremove = "java.sql.SQLSyntaxErrorException: ";
            String result = Exceptioninput.replaceAll(Exceptionremove, "");
            System.out.println(result);
            error = result;
        }
    }

    /**
     * Remove content which is type of int .
     *
     * @param table
     * @param indexColumnName
     * @param content
     * @throws SQLException
     */
    public void deleteRow(String table, String indexColumnName, String content) throws SQLException {
        reset();
        stmt = conn.createStatement();
        String tablefix = textfix(table);
        ResultSet rs;
        rs = stmt.executeQuery("select * from " + tablefix);
        ResultSetMetaData rsmd = rs.getMetaData();
        String checkType = rsmd.getColumnTypeName(1);
        if (checkType.equals("INTEGER")) {
            try {
                //   String tablefix = textfix(table);
                String IntegerindexColumnfix = textfix(indexColumnName);
                int contentfix = Integer.parseInt(content);
                sql = "DELETE FROM " + tablefix + " WHERE " + IntegerindexColumnfix + "= " + contentfix;
                stmt.execute("DELETE FROM " + tablefix + " WHERE " + IntegerindexColumnfix + "= " + contentfix);
                stmt.close();
                stmt = null;
                terminate = "Delete success if the target was exist";
            } catch (SQLException e) {
                String Exceptioninput = e.toString();
                String Exceptionremove = "java.sql.SQLSyntaxErrorException: ";
                String result = Exceptioninput.replaceAll(Exceptionremove, "");
                System.out.println(result);
                error = result;
            }
        } else if (checkType.equals("VARCHAR")) {
            try {
                String VARCHARIndexColumnFIX = textfix(indexColumnName);

                sql = "DELETE FROM " + tablefix + " WHERE " + VARCHARIndexColumnFIX + "= " + content;
                stmt.execute("DELETE FROM " + tablefix + " WHERE " + VARCHARIndexColumnFIX + "= '" + content + "' ");
                stmt.close();
                stmt = null;
                terminate = "Delete success if the target was exist";

            } catch (SQLException e) {
                String Exceptioninput = e.toString();
                String Exceptionremove = "java.sql.SQLSyntaxErrorException: ";
                String result = Exceptioninput.replaceAll(Exceptionremove, "");
                System.out.println(result);
                error = result;

            }

        }
        rs.close();
    }

    /**
     * Disconnect to the Apache Derby.
     *
     */
    public void shutDown() {
        reset();
        try {
            if (stmt != null) {
                stmt.close();
            }
            if (conn != null) {
                DriverManager.getConnection(dbURL2 + ";shutdown=true");
                conn.close();
            }
        } catch (SQLException sqlExcept) {

        }

    }

    /**
     * Create table which i s base on Nx3 column . This method has been replace.
     *
     * @param table
     * @param firstCategory
     * @param secondCategory
     * @param thirdCategory
     * @throws SQLException
     */
    private void createTable(String table, String firstCategory, String secondCategory, String thirdCategory) throws SQLException {
        reset();
        //String firstCategory,String secondCategory,String thirdCategory
        stmt = conn.createStatement();
        String tabledone = textfix(table);
        String firstCategoryfix = textfix(firstCategory);
        String secondCategoryfix = textfix(secondCategory);
        String thirdCategoryfix = textfix(thirdCategory);
        try {

            String sql = "CREATE TABLE " + tabledone + "(" + firstCategoryfix + " INT PRIMARY KEY," + secondCategoryfix + " VARCHAR(100)," + thirdCategoryfix + " VARCHAR(100))";
            // String sql = "CREATE TABLE " + tabledone + "(ID INT PRIMARY KEY,NAME VARCHAR(100),NAME2 VARCHAR(100))";
            System.out.println(sql);
            stmt.executeUpdate(sql);
            stmt.close();
            terminate = "create success";
        } catch (SQLException e) {
            String Exceptioninput = e.toString();
            String Exceptionremove = "java.sql.SQLSyntaxErrorException: ";
            String result = Exceptioninput.replaceAll(Exceptionremove, "");
            System.out.println(result);
            error = result + "\n wrong input ,\nthe correct input might be table-name/firstcategory/category2/category3/";

        }
        stmt = null;
    }

    /**
     * Remove Table.
     *
     * @param table
     * @throws SQLException
     */
    public void deleteTable(String table) throws SQLException, Exception {
        if ("".equals(table) || table == null || table.equals("null")) {
            error = "the table cannot be empty or Null";
            throw new Exception("the table cannot be empty or Null");

        }
        reset();
        String tabledone = textfix(table);
        stmt = conn.createStatement();
        try {

            sql = "DROP TABLE " + tabledone;
            stmt.executeUpdate(sql);
            // throw new Exception("");
            stmt.close();
            terminate = "success  ";
        } catch (SQLException e) {
            String Exceptioninput = e.toString();
            String Exceptionremove = "java.sql.SQLSyntaxErrorException: ";
            String result = Exceptioninput.replaceAll(Exceptionremove, "");
            System.out.println(result);
            error = result;
        }
        stmt = null;
    }

    /**
     * Insert content into table.This method has been replace.
     *
     * @param table
     * @param category1
     * @param category2
     * @param category3
     */
    private void insertTable(String table, int category1, String category2, String category3) {
        reset();
        try {
            String tabledone = textfix(table);

            stmt = conn.createStatement();
            stmt.execute("insert into " + tabledone + " values ("
                    + category1 + ",'" + category2 + "','" + category3 + "')");
            System.out.println("insert success");
            terminate = "insert success";
            stmt.close();
        } catch (SQLException e) {
            String Exceptioninput = e.toString();
            String Exceptionremove = "java.sql.SQLSyntaxErrorException: ";
            String result = Exceptioninput.replaceAll(Exceptionremove, "");
            System.out.println(result);
            error = result;
        }
        stmt = null;
    }

    /**
     * Change content int any table.This method has been replace.
     *
     * @param table
     * @param indexContent
     * @param targetColumnName
     * @param indexColumnName
     * @param resultContent
     */
    private void changeTableTargetcontent(String table, int indexContent, String indexColumnName, String targetColumnName, String resultContent) {
        reset();
        try {
            String tabledone = textfix(table);
            String targetcategoryfix = textfix(targetColumnName);
            String firstcategoryfix = textfix(indexColumnName);
            String sql = " update " + tabledone + " set " + targetcategoryfix + " = '" + resultContent + "' where " + firstcategoryfix + "= " + indexContent;
            stmt = conn.createStatement();
            stmt.executeUpdate(sql);
            stmt.close();
            terminate = "success!!";
        } catch (SQLException e) {
            String Exceptioninput = e.toString();
            String Exceptionremove = "java.sql.SQLSyntaxErrorException: ";
            String result = Exceptioninput.replaceAll(Exceptionremove, "");
            System.out.println(result);
            error = result;
        }
        stmt = null;
    }

    /**
     * This method has been replace.
     *
     * @param table
     * @param indexContent
     * @param indexColumnName
     * @param targetColumnName
     * @param resultContent
     */
    private void changeTableTargetcontent(String table, int indexContent, String indexColumnName, String targetColumnName, int resultContent) {
        reset();
        try {
            String tabledone = textfix(table);
            String targetcategoryfix = textfix(targetColumnName);
            String firstcategoryfix = textfix(indexColumnName);
            sql = " update " + tabledone + " set " + targetcategoryfix + "  = " + resultContent + " where " + firstcategoryfix + "= " + indexContent;
            stmt = conn.createStatement();
            stmt.executeUpdate(sql);
            stmt.close();
            terminate = "success!!";
        } catch (SQLException e) {
            String Exceptioninput = e.toString();
            String Exceptionremove = "java.sql.SQLSyntaxErrorException: ";
            String result = Exceptioninput.replaceAll(Exceptionremove, "");
            System.out.println(result);
            error = result;
        }
        stmt = null;
    }

    /**
     * Show table content.
     *
     * @param table
     */
    public void showTable(String table) {
        reset();
        try {

            String tablefix = textfix(table);
            stmt = conn.createStatement();
            sql = "select * from " + tablefix;
            ResultSet results = stmt.executeQuery(sql);
            ResultSetMetaData rsmd = results.getMetaData();
            int numberCols = rsmd.getColumnCount();
            for (int i = 1; i <= numberCols; i++) {
                //print Column Names

                System.out.print(rsmd.getColumnLabel(i) + "\t\t|\t\t");
                storemessage = rsmd.getColumnLabel(i) + "\t\t|\t\t";
                terminate = terminate + storemessage;
            }

            System.out.println("\n-------------------------------------------------");
            storemessage = "\n-------------------------------------------------\n";
            terminate = terminate + storemessage;

            while (results.next()) {

                //  int a=results.getInt(1);
                //System.out.println(a);
                //rminate = terminate + storemessage;
                // System.out.println(numberCols);
                for (int k = 1; k <= numberCols; k++) {
                    String checkType = rsmd.getColumnTypeName(k);
                    //System.out.println(checkType);
                    if ("INTEGER".equals(checkType)) {
                        int a = results.getInt(k);
                        storemessage = a + "\t\t|\t\t";
                        System.out.print(storemessage);

                        terminate = terminate + storemessage;
                    } else if ("VARCHAR".equals(checkType)) {
                        String b = results.getString(k);
                        storemessage = b + "\t\t|\t\t";
                        System.out.print(b + "\t\t|\t\t");
                        terminate = terminate + storemessage;
                    } else {
                        String b = results.getString(k);
                        storemessage = b + "\t\t|\t\t";
                        System.out.print(b + "\t\t|\t\t");
                        terminate = terminate + storemessage;

                    }

                }
                storemessage = "\n";
                terminate = terminate + storemessage;
                System.out.print(storemessage);
            }
            //terminate = terminate;
            //  System.out.println(terminate);
            results.close();
            stmt.close();
            //storemessage=null;
            //terminate=null;
        } catch (SQLException e) {

            String Exceptioninput = e.toString();
            String Exceptionremove = "java.sql.SQLSyntaxErrorException: ";
            String result = Exceptioninput.replaceAll(Exceptionremove, "");
            System.out.println(result);
            error = result + "\nwrong input\nthe correct input is\nTable-name";
        }
    }

    /**
     * Show the content list of Category in any table.
     *
     * @param table
     * @param ColumnName
     */
    public void showColumnContent(String table, String ColumnName) {
        reset();
        try {
            String tablefix = textfix(table);
            String categoryfix = textfix(ColumnName);
            stmt = conn.createStatement();
            sql = "SELECT " + categoryfix + " FROM " + tablefix;
            ResultSet rs;
            rs = stmt.executeQuery(sql);
            //ResultSetMetaData rsmd = rs.getMetaData();
            while (rs.next()) {
                String a = rs.getString(ColumnName);
                System.out.print(a + "\n");
                storemessage = a + "\n";
                terminate = terminate + storemessage;
            }

            rs.close();
        } catch (SQLException e) {
            String Exceptioninput = e.toString();
            String Exceptionremove = "java.sql.SQLSyntaxErrorException: ";
            String result = Exceptioninput.replaceAll(Exceptionremove, "");
            System.out.println(result);
            error = result + "\nwrong input \ncorrect input is table-name \\targetcategory";
        }
        stmt = null;
    }

    /**
     * Show all table which is exist.
     *
     */
    public void showAllTable() {//schema rely//capital letter rely// the default-schema will be your user name(always capital letter)
        reset();
        try {
            //String schemafix = textfix(schema);
            String userfix = user;
            String user2 = userfix.toUpperCase();
            //ResultSetMetaData rsmd = rs.getMetaData();
            DatabaseMetaData md = conn.getMetaData();
            ResultSet rs = md.getTables(null, user, "%", null);
            while (rs.next()) {
                System.out.println(rs.getString(3));
                storemessage = rs.getString(3) + "\n";
                terminate = terminate + storemessage;
            }

            rs.close();
        } catch (SQLException e) {
            String Exceptioninput = e.toString();
            String Exceptionremove = "java.sql.SQLSyntaxErrorException: ";
            String result = Exceptioninput.replaceAll(Exceptionremove, "");
            System.out.println(result);
            error = result;
        }
        stmt = null;
    }

    /**
     * Search content in any table.This method has been replace.
     *
     * @param table
     * @param indexColumnName
     * @param secondCategory
     * @param thirdCategory
     * @param integerCategorycontent
     */
    private void searchIndex(String table, String indexColumnName, String secondCategory, String thirdCategory, int integerCategorycontent) {
        reset();
        try {
            String tabledone = textfix(table);
            String integerCategoryfix = textfix(indexColumnName);
            stmt = conn.createStatement();
            // sql=
            ResultSet rs;
            rs = stmt.executeQuery("SELECT * FROM " + tabledone + " WHERE " + integerCategoryfix + " = " + integerCategorycontent);
            //ResultSetMetaData rsmd = rs.getMetaData();
            while (rs.next()) {
                String a = rs.getString(secondCategory);
                System.out.print(a + "\t");
                storemessage = a + "\t";
                terminate = terminate + storemessage;
                String b = rs.getString(thirdCategory);
                System.out.print(b + "\t");
                storemessage = b + "\t";
                terminate = terminate + storemessage;

            }

            rs.close();
        } catch (SQLException e) {
            String Exceptioninput = e.toString();
            String Exceptionremove = "java.sql.SQLSyntaxErrorException: ";
            String result = Exceptioninput.replaceAll(Exceptionremove, "");
            System.out.println(result);
            error = result;
        }
        stmt = null;
    }//need to fix

    /**
     * Response error if error happens.
     * this method should use immediately after executing other method
     *
     * @return
     */
    public String errorResponse() {

        return "\n" + error;
    }

    /**
     * Response output if the method has outputs.
     * this method should use immediately after executing other method
     *
     * @return method output details
     */
    public String output() {
        return  terminate;
    }

    /**
     * rename Category
     *
     * @param table
     * @param ColumnName
     * @param ResultColumnName
     * @throws SQLException
     */
    public void renameColumn(String table, String ColumnName, String ResultColumnName) throws SQLException {
        reset();
        //String firstCategory,String secondCategory,String thirdCategory
        stmt = conn.createStatement();
        String tabledone = textfix(table);
        String Categorynamefix = textfix(ColumnName);
        String resultCategorynamefix = textfix(ResultColumnName);

        try {

            sql = "RENAME COLUMN " + tabledone + "." + Categorynamefix + " TO " + resultCategorynamefix;
            // String sql = "CREATE TABLE " + tabledone + "(ID INT PRIMARY KEY,NAME VARCHAR(100),NAME2 VARCHAR(100))";
            stmt.executeUpdate(sql);
            stmt.close();
        } catch (SQLException e) {
            String Exceptioninput = e.toString();
            String Exceptionremove = "java.sql.SQLSyntaxErrorException: ";
            String result = Exceptioninput.replaceAll(Exceptionremove, "");
            System.out.println(result);
            error = result;

        }
        stmt = null;
    }

    /**
     * rename the Table which is chosen.
     *
     * @param table
     * @param resultTable
     * @throws SQLException
     */
    public void renameTable(String table, String resultTable) throws SQLException {
        reset();
        //String firstCategory,String secondCategory,String thirdCategory
        stmt = conn.createStatement();
        String tabledone = textfix(table);
        String resultTablefix = textfix(resultTable);
        //String Categorynamefix = textfix(Categoryname);
        //String resultCategorynamefix = textfix(resultCategoryname);

        try {

            sql = "RENAME Table " + tabledone + " to " + resultTablefix;
            // String sql = "CREATE TABLE " + tabledone + "(ID INT PRIMARY KEY,NAME VARCHAR(100),NAME2 VARCHAR(100))";
            stmt.executeUpdate(sql);
            stmt.close();
        } catch (SQLException e) {
            String Exceptioninput = e.toString();
            String Exceptionremove = "java.sql.SQLSyntaxErrorException: ";
            String result = Exceptioninput.replaceAll(Exceptionremove, "");
            System.out.println(result);
            error = result;

        }
        stmt = null;

    }

    /**
     * search the category value which the value is between min and maxium
     *
     * @param table
     * @param indexColunmName
     * @param ComparedColumnName
     * @param min
     * @param max
     * @throws InterruptedException
     */
    public void searchbetween(String table, String indexColunmName, String ComparedColumnName, int min, int max) throws InterruptedException {
        reset();
        try {
            String tabledone = textfix(table);
            // String firstcategoryfix = textfix(indexColunmName);
            //  String Comparedcategoryfix = textfix(ComparedColumnName);

            stmt = conn.createStatement();
            sql = "SELECT * FROM " + tabledone;
            ResultSet rs;
            rs = stmt.executeQuery(sql);
            //ResultSetMetaData rsmd = rs.getMetaData();
           // Thread.sleep(1000);

            while (rs.next()) {
                String input1 = rs.getString(indexColunmName);
                String input2 = rs.getString(ComparedColumnName);
                int compared;
                try {
                    compared = Integer.parseInt(input2);
                    //throw new Exception ("");
                    if (min <= compared && compared <= max) {
                       // System.out.print(input1 + "\t");
                        //System.out.print(compared + "\n");
                        storemessage = input1 +"|"+ compared + "\n";
                        terminate = terminate + storemessage;
                    }
                } catch (Exception e) {

                }

            }

            rs.close();
        } catch (SQLException e) {
            String Exceptioninput = e.toString();
            String ExceptionRemove = "java.sql.SQLSyntaxErrorException: ";
            String result = Exceptioninput.replaceAll(ExceptionRemove, "");
            System.out.println(result);
            error = result;
        }
        stmt = null;
    }

    /**
     * Change Schema temporary.This method is used when this class is
     * initialized to other user This method should be use before the target
     * method is executed.
     *
     * @param schemaname
     * @throws SQLException
     */
    public void setSchema(String schemaname) throws SQLException {
        reset();
        String schemanamefix = textfix(schemaname);
        //String firstCategory,String secondCategory,String thirdCategory
        stmt = conn.createStatement();
        //String tabledone = textfix(table);
        //String firstCategoryfix = textfix(firstCategory);
        //String secondCategoryfix = textfix(secondCategory);
        //String thirdCategoryfix = textfix(thirdCategory);
        try {

            sql = "set current schema " + schemanamefix;
            // String sql = "CREATE TABLE " + tabledone + "(ID INT PRIMARY KEY,NAME VARCHAR(100),NAME2 VARCHAR(100))";

            stmt.executeUpdate(sql);
            stmt.close();
            System.out.println("Notice the default-schema is your user name!!");
            System.out.println("all method  must be execute after this method if you want to change your current schema");
            terminate = "create success";
        } catch (SQLException e) {
            String Exceptioninput = e.toString();
            String Exceptionremove = "java.sql.SQLSyntaxErrorException: ";
            String result = Exceptioninput.replaceAll(Exceptionremove, "");
            System.out.println(result);
            error = result + "\n wrong input ,\nthe correct input might be table-name/firstcategory/category2/category3/";

        }
        stmt = null;
    }

    /**
     * Show all Schema
     *
     */
    public void showAllSCHEMA() {//schema rely
        reset();
        try {

            //ResultSetMetaData rsmd = rs.getMetaData();
            DatabaseMetaData md = conn.getMetaData();
            ResultSet rs = md.getSchemas();
            while (rs.next()) {
                System.out.println(rs.getString(1));
                storemessage = rs.getString(1) + "\n";
                terminate = terminate + storemessage;
            }

            rs.close();
        } catch (SQLException e) {
            String Exceptioninput = e.toString();
            String Exceptionremove = "java.sql.SQLSyntaxErrorException: ";
            String result = Exceptioninput.replaceAll(Exceptionremove, "");
            System.out.println(result);
            error = result;
        }
        stmt = null;
    }

    /**
     * Creating schema
     *
     * @param schemaName
     * @throws SQLException
     */
    public void createSchema(String schemaName) throws SQLException {
        reset();
        //String firstCategory,String secondCategory,String thirdCategory
        stmt = conn.createStatement();
        String namefix = textfix(schemaName);
        //String tabledone = textfix(table);
        //String firstCategoryfix = textfix(firstCategory);
        //String secondCategoryfix = textfix(secondCategory);
        //String thirdCategoryfix = textfix(thirdCategory);
        try {

            sql = "Create schema " + namefix;
            // String sql = "CREATE TABLE " + tabledone + "(ID INT PRIMARY KEY,NAME VARCHAR(100),NAME2 VARCHAR(100))";

            stmt.executeUpdate(sql);
            stmt.close();
            System.out.println("Notice the default-schema is your user name!!");
            terminate = "create success";
        } catch (SQLException e) {
            String Exceptioninput = e.toString();
            String Exceptionremove = "java.sql.SQLSyntaxErrorException: ";
            String result = Exceptioninput.replaceAll(Exceptionremove, "");
            System.out.println(result);
            error = result + "\n wrong input ,\nthe correct input might be table-name/firstcategory/category2/category3/";

        }
        stmt = null;
    }

    /**
     * Dont use this method
     *
     * @param a
     * @return
     */
    private void setuser(String a) {

        user = a;

    }

    /**
     * Delete schema
     *
     * @param schemaName
     * @throws SQLException
     */
    public void deleteSchema(String schemaName) throws SQLException {
        reset();
        //String firstCategory,String secondCategory,String thirdCategory
        stmt = conn.createStatement();
        String namefix = textfix(schemaName);
        //String tabledone = textfix(table);
        //String firstCategoryfix = textfix(firstCategory);
        //String secondCategoryfix = textfix(secondCategory);
        //String thirdCategoryfix = textfix(thirdCategory);
        try {

            sql = "DROP SCHEMA " + namefix + " RESTRICT";
            // String sql = "CREATE TABLE " + tabledone + "(ID INT PRIMARY KEY,NAME VARCHAR(100),NAME2 VARCHAR(100))";

            stmt.executeUpdate(sql);
            stmt.close();
            System.out.println("Notice the default-schema is your user name!!");
            terminate = " success";
        } catch (SQLException e) {
            String Exceptioninput = e.toString();
            String Exceptionremove = "java.sql.SQLSyntaxErrorException: ";
            String result = Exceptioninput.replaceAll(Exceptionremove, "");
            System.out.println(result);
            error = result + "\n wrong input ,\nthe correct input might be table-name/firstcategory/category2/category3/";

        }
        stmt = null;

    }

    /**
     * Delete all the rows except all of the Column name
     *
     * @param tablename
     * @throws SQLException
     */
    public void deleteAlltablecontent(String tablename) throws SQLException {
        reset();
        //String firstCategory,String secondCategory,String thirdCategory
        stmt = conn.createStatement();
        String tablenamefix = textfix(tablename);
        // String namefix = textfix(schemaName);
        //String tabledone = textfix(table);
        //String firstCategoryfix = textfix(firstCategory);
        //String secondCategoryfix = textfix(secondCategory);
        //String thirdCategoryfix = textfix(thirdCategory);
        try {

            sql = "Delete From " + tablenamefix;
            // String sql = "CREATE TABLE " + tabledone + "(ID INT PRIMARY KEY,NAME VARCHAR(100),NAME2 VARCHAR(100))";

            stmt.executeUpdate(sql);
            stmt.close();
            // System.out.println("Notice the default-schema is your user name!!");
            terminate = " success";
        } catch (SQLException e) {
            String Exceptioninput = e.toString();
            String Exceptionremove = "java.sql.SQLSyntaxErrorException: ";
            String result = Exceptioninput.replaceAll(Exceptionremove, "");
            System.out.println(result);
            error = result + "\n wrong input ,\nthe correct input might be table-name/firstcategory/category2/category3/";

        }
        stmt = null;
    }

    /**
     * create table the first Column is always a primary key amd the type is
     * Integer the other Columns are always type of Varchar which have 100
     * space.(VARCHAR(100))
     *
     *
     * @param numberofColumn
     * @param tableName
     * @param eachColumnName
     * @throws SQLException
     * @throws Exception
     */
    public void createTable(int numberofColumn, String tableName, String eachColumnName) throws SQLException, Exception {
        reset();//the Primary key must be unique and must not be null also ca be reference by foreign key
        stmt = conn.createStatement();
        String temporary = "(";
        if (numberofColumn == 0 || numberofColumn < 0) {
            error = "wrong input the numberofColumn must bigger than 0\n";
            throw new Exception("wrong input the numberofColumn must bigger than 0");
        } else {
            try {
                String tableNamefix = textfix(tableName);
                // ArrayList one = new ArrayList();
                String input[] = eachColumnName.split(",");
                for (int i = 0; i < numberofColumn; i++) {
                    String fix = input[i];
                    String fixinput = textfix(fix);
                    if (i == 0 && numberofColumn != 1) {
                        temporary = temporary + fixinput + " int PRIMARY KEY,";
                    } else if (i < numberofColumn - 1 && numberofColumn != 1) {
                        String varchar = " VARCHAR(100),";
                        temporary = temporary + fixinput + varchar;
                    } else {
                        if (numberofColumn == 1) {
                            String varchar = " int PRIMARY KEY)";

                            temporary = temporary + fixinput + varchar;
                        } else {
                            String varchar = " VARCHAR(100))";

                            temporary = temporary + fixinput + varchar;
                        }
                    }
                    // String Key=" PRIMARY KEY ";
                }
                sql = "CREATE TABLE " + tableNamefix + temporary;
                // String sql = "CREATE TABLE " + tabledone + "(ID INT PRIMARY KEY,NAME VARCHAR(100),NAME2 VARCHAR(100))";
                System.out.println(sql);
                stmt.executeUpdate(sql);
                stmt.close();
                // System.out.println("Notice the default-schema is your user name!!");
                terminate = "create success";
            } catch (SQLException e) {
                String Exceptioninput = e.toString();
                String Exceptionremove = "java.sql.SQLSyntaxErrorException: ";
                String result = Exceptioninput.replaceAll(Exceptionremove, "");
                System.out.println(result);
                error = result + "\n\n your input(eachColumnName) must be seperate by ,";

            }
            stmt = null;
        }
    }

    /**
     * This method has been replace.
     *
     * @param numberOfColumn
     * @param table
     * @param input
     * @throws Exception
     */
    private void insertTable(int numberOfColumn, String table, String input) throws Exception {
        reset();
        stmt = conn.createStatement();
        if (numberOfColumn == 0 || numberOfColumn < 0) {
            error = "wrong input the numberofColumn must bigger than 0\n";
            throw new Exception("wrong input the numberofColumn must bigger than 0");

        } else {
            try {
                String tabledone = textfix(table);
                String temporary = "insert into ";
                temporary = temporary + tabledone + " values ( ";
                String input1[] = input.split(",");

                for (int i = 0; i < numberOfColumn; i++) {
                    if (i == 0 && numberOfColumn != 1) {

                        String firstInput = input1[i];
                        String resultInput = textfix(firstInput);
                        try {
                            int firstInputFix = Integer.parseInt(firstInput);
                        } catch (NumberFormatException e) {
                            System.out.println(e);
                            error = "wrong input the first input must be Integer because you define the first column type must be integer\n";
                            throw new Exception("wrong input the first input must be Integer because you define the first column type must be integer");
                        }
                        temporary = temporary + firstInput + ",'";

                    } else if (i < numberOfColumn - 1 && numberOfColumn != 1) {
                        String otherInput = input1[i];
                        temporary = temporary + otherInput + "','";
                    } else {
                        if (numberOfColumn == 1) {
                            String firstInput = input1[i];
                            try {
                                int firstInputFix = Integer.parseInt(firstInput);
                            } catch (NumberFormatException e) {
                                System.out.println(e);
                                error = "wrong input the first input must be Integer because you define the first column type must be integer\n";
                                throw new Exception("wrong input the first input must be Integer because you define the first column type must be integer");
                            }

                            temporary = temporary + firstInput + ")";

                        } else {
                            String otherInput = input1[i];
                            temporary = temporary + otherInput + "')";
                        }
                    }

                }
                String sql = temporary;
                /* String sql="\"insert into \" + tabledone + \" values (\"\n" +
"          /         + category1 + \",'\" + category2 + \"','\" + category3 + \"')\"";*/
                System.out.println(sql);
                stmt.execute(sql);
                System.out.println("insert success");
                terminate = "insert success";
                stmt.close();
            } catch (SQLException e) {
                String Exceptioninput = e.toString();
                String Exceptionremove = "java.sql.SQLSyntaxErrorException: ";
                String result = Exceptioninput.replaceAll(Exceptionremove, "");
                System.out.println(result);
                error = result + "your input must seperate with ,";
            }
        }
        stmt = null;
    }

    /**
     * showAll table from other schema if the schema is exist.
     *
     * @param schema
     */
    public void showAllTable(String schema) {//schema rely//capital letter rely// the default-schema will be your user name(always capital letter)
        reset();
        try {
            //String schemafix = textfix(schema);
            String userfix = user;
            String user2 = userfix.toUpperCase();
            //ResultSetMetaData rsmd = rs.getMetaData();
            DatabaseMetaData md = conn.getMetaData();
            ResultSet rs = md.getTables(null, schema, "%", null);
            while (rs.next()) {
                System.out.println(rs.getString(3));
                storemessage = rs.getString(3) + "\n";
                terminate = terminate + storemessage;
            }

            rs.close();
        } catch (SQLException e) {
            String Exceptioninput = e.toString();
            String Exceptionremove = "java.sql.SQLSyntaxErrorException: ";
            String result = Exceptioninput.replaceAll(Exceptionremove, "");
            System.out.println(result);
            error = result;
        }
        stmt = null;
    }

    /**
     * create table the first Column is always a primary key the Columns are
     * always type of Varchar which have 100 space.(VARCHAR(100))
     *
     *
     * @param numberofColumn
     * @param tableName
     * @param eachColumnName
     * @throws SQLException
     * @throws Exception
     */
    public void createTableAllVarchar(int numberofColumn, String tableName, String eachColumnName) throws SQLException, Exception {
        reset();//the Primary key must be unique and must nt be null also ca be reference by foreign key
        stmt = conn.createStatement();
        String temporary = "(";
        if (numberofColumn == 0 || numberofColumn < 0) {
            error = "wrong input the numberofColumn must bigger than 0\n";
            throw new Exception("wrong input the numberofColumn must bigger than 0");
        } else {
            try {
                String tableNamefix = textfix(tableName);
                // ArrayList one = new ArrayList();
                String input[] = eachColumnName.split(",");
                for (int i = 0; i < numberofColumn; i++) {
                    String fix = input[i];
                    String fixinput = textfix(fix);
                    if (i == 0 && numberofColumn != 1) {
                        temporary = temporary + fixinput + " VARCHAR(100) PRIMARY KEY,";
                    } else if (i < numberofColumn - 1 && numberofColumn != 1) {
                        String varchar = " VARCHAR(100),";
                        temporary = temporary + fixinput + varchar;
                    } else {
                        if (numberofColumn == 1) {
                            String varchar = " VARCHAR(100) PRIMARY KEY)";
                            temporary = temporary + fixinput + varchar;
                        } else {
                            String varchar = " VARCHAR(100))";
                            temporary = temporary + fixinput + varchar;
                        }
                    }
                    // String Key=" PRIMARY KEY ";
                }
                sql = "CREATE TABLE " + tableNamefix + temporary;
                // String sql = "CREATE TABLE " + tabledone + "(ID INT PRIMARY KEY,NAME VARCHAR(100),NAME2 VARCHAR(100))";
                System.out.println(sql);
                stmt.executeUpdate(sql);
                stmt.close();
                // System.out.println("Notice the default-schema is your user name!!");
                terminate = "create success";
            } catch (SQLException e) {
                String Exceptioninput = e.toString();
                String Exceptionremove = "java.sql.SQLSyntaxErrorException: ";
                String result = Exceptioninput.replaceAll(Exceptionremove, "");
                System.out.println(result);
                error = result + "\n\n your input(eachColumnName) must be seperate by ,\n";

            }
            stmt = null;
        }

    }

    /**
     * This method has been replace.
     *
     * @param numberOfColumn
     * @param table
     * @param input
     * @throws Exception
     */
    private void insertTableAllVarchar(int numberOfColumn, String table, String input) throws Exception {
        reset();
        stmt = conn.createStatement();
        if (numberOfColumn == 0 || numberOfColumn < 0) {
            error = "wrong input the numberofColumn must bigger than 0\n";
            throw new Exception("wrong input the numberofColumn must bigger than 0");

        } else {
            try {
                String tabledone = textfix(table);
                String temporary = "insert into ";
                temporary = temporary + tabledone + " values ( '";
                String input1[] = input.split(",");

                for (int i = 0; i < numberOfColumn; i++) {
                    if (i == 0 && numberOfColumn != 1) {

                        String firstInput = input1[i];

                        temporary = temporary + firstInput + "','";

                    } else if (i < numberOfColumn - 1 && numberOfColumn != 1) {
                        String otherInput = input1[i];
                        temporary = temporary + otherInput + "','";
                    } else {
                        String otherInput = input1[i];
                        temporary = temporary + otherInput + "')";
                    }

                }
                sql = temporary;
                /* String sql="\"insert into \" + tabledone + \" values (\"\n" +
"          /         + category1 + \",'\" + category2 + \"','\" + category3 + \"')\"";*/
                System.out.println(sql);
                stmt.execute(sql);
                System.out.println("insert success");
                terminate = "insert success";
                stmt.close();
            } catch (SQLException e) {
                String Exceptioninput = e.toString();
                String Exceptionremove = "java.sql.SQLSyntaxErrorException: ";
                String result = Exceptioninput.replaceAll(Exceptionremove, "");
                System.out.println(result);
                error = result + "your input must seperate with ,";
            }
        }
        stmt = null;
    }

    /**
     * Search content by index
     *
     * @param table
     * @param indexColumnName
     * @param index
     * @throws java.sql.SQLException
     */
    public void searchIndex(String table, String indexColumnName, String index) throws SQLException {
        reset();
        String tablefix = textfix(table);
        String indexColumnNamefix = textfix(indexColumnName);
        ResultSet rs;
        stmt = conn.createStatement();
        try {

            rs = stmt.executeQuery("select * from " + tablefix);
            ResultSetMetaData rsmd = rs.getMetaData();
            String checkType = rsmd.getColumnTypeName(1);
            if ("INTEGER".equals(checkType)) {
                stmt.close();
                stmt = null;
                stmt = conn.createStatement();

                int indexfix = 0;
                try {
                    indexfix = Integer.parseInt(index);
                    throw new Exception("your first column type is int");

                } catch (Exception e) {
                    error = "your first column type is int";
                }
                sql = "SELECT * FROM " + tablefix + " WHERE " + indexColumnNamefix + " = " + indexfix;
                try{
                rs = stmt.executeQuery(sql);
                }catch(SQLException e){
                     error =e.toString();
                }
                // stmt.close();
            } else if ("VARCHAR".equals(checkType)) {
                stmt.close();
                stmt = null;
                stmt = conn.createStatement();
                sql = "SELECT * FROM " + tablefix + " WHERE " + indexColumnNamefix + " = '" + index + "'";
                try{
                rs = stmt.executeQuery(sql);
                }catch(SQLException e){
                     error =e.toString();
                }
                
                //stmt.close();

            }
            int numberCols = rsmd.getColumnCount();
            while (rs.next()) {
                for (int k = 1; k <= numberCols; k++) {
                    checkType = rsmd.getColumnTypeName(k);
                    //System.out.println(checkType);
                    if ("INTEGER".equals(checkType)) {
                        int a = rs.getInt(k);
                        storemessage = a + "|";
                      //  System.out.print(storemessage);

                        terminate = terminate + storemessage;
                    } else if ("VARCHAR".equals(checkType)) {
                        String b = rs.getString(k);
                        storemessage = b + "|";
                       // System.out.print(b + "|");
                        terminate = terminate + storemessage;
                    }else{
                        String b = rs.getString(k);
                        storemessage = b + "|";
                     //   System.out.print(b + "|");
                        terminate = terminate + storemessage;
                    }

                }

            }
            stmt.close();
            rs.close();
        } catch (SQLException e) {
            String Exceptioninput = e.toString();
            String Exceptionremove = "java.sql.SQLSyntaxErrorException: ";
            String result = Exceptioninput.replaceAll(Exceptionremove, "");
            System.out.println(result);
            error = result; //+ "\nwrong input\nthe correct input is\nTable-name";

        }
        stmt = null;

//        stmt.close();
    }

    /**
     * change the chosen content
     *
     * @param table
     * @param index
     * @param targetColumnName
     * @param resultContent
     * @throws java.sql.SQLException
     */
    public void changeTableTargetcontent(String table, String index, String targetColumnName, String resultContent) throws SQLException {
        reset();
        String tablefix = textfix(table);
        String targetColumnNamefix = textfix(targetColumnName);
        ResultSet rs;
        stmt = conn.createStatement();
        try {
            rs = stmt.executeQuery("select * from " + tablefix);
            ResultSetMetaData rsmd = rs.getMetaData();
            String checkType = rsmd.getColumnTypeName(1);
            if ("INTEGER".equals(checkType)) {
                // System.out.println("hi there");

                String compared = rsmd.getColumnName(1);
                if (targetColumnName.equals(compared)) {
                    // System.out.println("hi there");
                    stmt.close();
                    stmt = null;
                    stmt = conn.createStatement();
                    String indexColumn = rsmd.getColumnName(1);
                    String indexColumnName = textfix(indexColumn);
                    int indexfix = Integer.parseInt(index);
                    int resultContentFix = Integer.parseInt(resultContent);
                    sql = " update " + tablefix + " set " + targetColumnNamefix + "  = " + resultContentFix + " where " + indexColumnName + "= " + indexfix;
                   // System.out.println(sql);
                    stmt.executeUpdate(sql);
                    stmt.close();
                    terminate = "success!!";
                } else {
                    stmt.close();
                    stmt = null;
                    stmt = conn.createStatement();
                    String indexColumn = rsmd.getColumnName(1);
                    String indexColumnName = textfix(indexColumn);
                    int indexfix = Integer.parseInt(index);
                    int resultContentFix = Integer.parseInt(resultContent);
                    sql = " update " + tablefix + " set " + targetColumnNamefix + "  = " + resultContent + " where " + indexColumnName + "= " + indexfix;
                   // System.out.println(sql);
                    stmt.executeUpdate(sql);
                    stmt.close();
                    terminate = "success!!";
                }
            } else if ("VARCHAR".equals(checkType)) {

                stmt.close();
                stmt = null;
                stmt = conn.createStatement();
                String indexColumn = rsmd.getColumnName(1);
                String indexColumnName = textfix(indexColumn);
                sql = " update " + tablefix + " set " + targetColumnNamefix + "  = '" + resultContent + "' where " + indexColumnName + "= '" + index+"'";
                stmt.executeUpdate(sql);
                stmt.close();
                terminate = "success!!";
            }
            rs.close();
        } catch (SQLException e) {
            String Exceptioninput = e.toString();
            String Exceptionremove = "java.sql.SQLSyntaxErrorException: ";
            String result = Exceptioninput.replaceAll(Exceptionremove, "");
            System.out.println(result);
            error = result;// + "\nwrong input\nthe correct input is\nTable-name";
        }
    }

    /**
     * Insert Table
     *
     * @param table
     * @param input
     * @throws SQLException
     * @throws Exception
     */
    public void insertTable(String table, String input) throws SQLException, Exception {
        reset();
        try {
            stmt = conn.createStatement();
            String tablefix = textfix(table);
            ResultSet rs;
            rs = stmt.executeQuery("select * from " + tablefix);
            ResultSetMetaData rsmd = rs.getMetaData();
            String checkType = rsmd.getColumnTypeName(1);
            int numberOfColumn = rsmd.getColumnCount();
            if ("INTEGER".equals(checkType)) {
                if (numberOfColumn == 0 || numberOfColumn < 0) {
                    error = "wrong input the numberofColumn must bigger than 0\n";
                    throw new Exception("wrong input the numberofColumn must bigger than 0");

                } else {
                    stmt.close();
                    stmt = null;
                    stmt = conn.createStatement();
                    String tabledone = textfix(table);
                    String temporary = "insert into ";
                    temporary = temporary + tabledone + " values ( ";
                    String input1[] = input.split(",");

                    for (int i = 0; i < numberOfColumn; i++) {
                        if (i == 0 && numberOfColumn != 1) {

                            String firstInput = input1[i];
                            String resultInput = textfix(firstInput);
                            try {
                                int firstInputFix = Integer.parseInt(firstInput);
                            } catch (NumberFormatException e) {
                                System.out.println(e);
                                error = "wrong input the first input must be Integer because you define the first column type must be integer\n";
                                throw new Exception("wrong input the first input must be Integer because you define the first column type must be integer");
                            }
                            temporary = temporary + firstInput + ",'";

                        } else if (i < numberOfColumn - 1 && numberOfColumn != 1) {
                            String otherInput = input1[i];
                            temporary = temporary + otherInput + "','";
                        } else {
                            if (numberOfColumn == 1) {
                                String firstInput = input1[i];
                                try {
                                    int firstInputFix = Integer.parseInt(firstInput);
                                } catch (NumberFormatException e) {
                                    System.out.println(e);
                                    error = "wrong input the first input must be Integer because you define the first column type must be integer\n";
                                    throw new Exception("wrong input the first input must be Integer because you define the first column type must be integer");
                                }

                                temporary = temporary + firstInput + ")";

                            } else {
                                String otherInput = input1[i];
                                temporary = temporary + otherInput + "')";
                            }
                        }

                    }
                    sql = temporary;
                    /* String sql="\"insert into \" + tabledone + \" values (\"\n" +
"          /         + category1 + \",'\" + category2 + \"','\" + category3 + \"')\"";*/
                    System.out.println(sql);
                    stmt.execute(sql);
                    System.out.println("insert success");
                    terminate = "insert success";
                    stmt.close();
                }
            } else if ("VARCHAR".equals(checkType)) {
                if (numberOfColumn == 0 || numberOfColumn < 0) {
                    error = "wrong input the numberofColumn must bigger than 0\n";
                    throw new Exception("wrong input the numberofColumn must bigger than 0");

                } else {
                    stmt.close();
                    stmt = null;
                    stmt = conn.createStatement();
                    String tabledone = textfix(table);
                    String temporary = "insert into ";
                    temporary = temporary + tabledone + " values ( '";
                    String input1[] = input.split(",");

                    for (int i = 0; i < numberOfColumn; i++) {
                        if (i == 0 && numberOfColumn != 1) {

                            String firstInput = input1[i];

                            temporary = temporary + firstInput + "','";

                        } else if (i < numberOfColumn - 1 && numberOfColumn != 1) {
                            String otherInput = input1[i];
                            temporary = temporary + otherInput + "','";
                        } else {
                            String otherInput = input1[i];
                            temporary = temporary + otherInput + "')";
                        }

                    }
                    sql = temporary;
                    /* String sql="\"insert into \" + tabledone + \" values (\"\n" +
"          /         + category1 + \",'\" + category2 + \"','\" + category3 + \"')\"";*/
                    System.out.println(sql);
                    stmt.execute(sql);
                    System.out.println("insert success");
                    terminate = "insert success";
                    stmt.close();
                }
            }
            // stmt.close();
        } catch (SQLException e) {
            String Exceptioninput = e.toString();
            String Exceptionremove = "java.sql.SQLSyntaxErrorException: ";
            String result = Exceptioninput.replaceAll(Exceptionremove, "");
            System.out.println(result);
            error = result + "your input must seperate with ,";
        }
        stmt = null;
    }

    /**
     * return sql statement if it exist
     * this method should use immediately after executing other method
     *
     * @return
     */
    public String sql() {
        return sql;
    }

    /**
     * Execute sql statement with out output this method is still testing may
     * have bug happen
     *
     * @param sql
     * @throws SQLException
     */
    public void sqlstatementExecute(String sql) throws SQLException {
        reset();
        ResultSet rs;
        stmt = conn.createStatement();
        try {
            // int a=0;
            // rs = stmt.executeQuery(sql);
            stmt.executeUpdate(sql);
            terminate = "execute success";
            stmt.close();
        } catch (SQLException e) {
            System.out.println(e);
            error = e.toString();
        }

    }

    /**Return tables Column name only if the table is exist
     *
     * @param table
     * @return
     */
    public String getTableColumnOnly(String table) {
        reset();
        try {

            String tablefix = textfix(table);
            stmt = conn.createStatement();
            sql = "select * from " + tablefix;
            ResultSet results = stmt.executeQuery(sql);
            ResultSetMetaData rsmd = results.getMetaData();
            int numberCols = rsmd.getColumnCount();
            for (int i = 1; i <= numberCols; i++) {
                //print Column Names
                if (i < numberCols) {
                    //  System.out.print(rsmd.getColumnLabel(i) + "|");
                    storemessage = rsmd.getColumnLabel(i) + "|";
                    terminate = terminate + storemessage;
                } else {
                    //    System.out.print(rsmd.getColumnLabel(i));
                    storemessage = rsmd.getColumnLabel(i);
                    terminate = terminate + storemessage;

                }
            }

            // System.out.println("\n-------------------------------------------------");
            // storemessage = "\n-------------------------------------------------\n";
            //terminate = terminate + storemessage;
            //terminate = terminate;
             // System.out.println(terminate);
            results.close();
            stmt.close();

            //storemessage=null;
            //terminate=null;
        } catch (SQLException e) {

            String Exceptioninput = e.toString();
            String Exceptionremove = "java.sql.SQLSyntaxErrorException: ";
            String result = Exceptioninput.replaceAll(Exceptionremove, "");
            System.out.println(result);
            error = result + "\nwrong input\nthe correct input is\nTable-name";
        }
        return terminate;

    }

    private void testing(String table) throws SQLException {
        try {
            // stmt = conn.createStatement();
            String tablefix = textfix("testing");
            String colfix = textfix("user");
            DatabaseMetaData md = conn.getMetaData();
            ResultSet rs = md.getColumnPrivileges(null, user, tablefix, colfix);
            ResultSetMetaData rsmd = rs.getMetaData();

            // Display the result set data.  
            int cols = rsmd.getColumnCount();
            System.out.println(cols);
            // System.out.println(rs.getString(1));
            while (rs.next()) {
                for (int i = 1; i <= cols; i++) {
                    System.out.println(rs.getString(i));
                    // storemessage = rs.getString(3) + "\n";
                    // terminate = terminate + storemessage;
                }
            }
            rs.close();
        } catch (SQLException e) {
            System.out.println(e.toString());
            e.printStackTrace();

        } catch (Exception e) {
            System.out.println(e.toString());
            e.printStackTrace();
        }

    }

    private void tesTsearchIndex(String table ,String indexColumnName, String index) throws SQLException {
        reset();
        String tableCheck[] = table.split(",");
        if (tableCheck.length == 1) {
            String tablefix = textfix(table);
            String indexColumnNamefix = textfix(indexColumnName);
            ResultSet rs;
            stmt = conn.createStatement();
            try {

                rs = stmt.executeQuery("select * from " + tablefix);
                ResultSetMetaData rsmd = rs.getMetaData();
                String checkType = rsmd.getColumnTypeName(1);
                if ("INTEGER".equals(checkType)) {
                    stmt.close();
                    stmt = null;
                    stmt = conn.createStatement();

                    int indexfix = 0;
                    try {
                        indexfix = Integer.parseInt(index);
                        throw new Exception("your first column type is int");

                    } catch (Exception e) {
                        error = "your first column type is int";
                    }
                    sql = "SELECT * FROM " + tablefix + " WHERE " + indexColumnNamefix + " = " + indexfix;
                    rs = stmt.executeQuery(sql);
                    // stmt.close();
                } else if ("VARCHAR".equals(checkType)) {
                    stmt.close();
                    stmt = null;
                    stmt = conn.createStatement();
                    sql = "SELECT * FROM " + tablefix + " WHERE " + indexColumnNamefix + " = '" + index + "'";
                    rs = stmt.executeQuery(sql);
                    //stmt.close();

                }
                int numberCols = rsmd.getColumnCount();
                while (rs.next()) {
                    for (int k = 1; k <= numberCols; k++) {
                        checkType = rsmd.getColumnTypeName(k);
                        //System.out.println(checkType);
                        if ("INTEGER".equals(checkType)) {
                            int a = rs.getInt(k);
                            storemessage = a + "\t\t|\t\t";
                            System.out.print(storemessage);

                            terminate = terminate + storemessage;
                        } else if ("VARCHAR".equals(checkType)) {
                            String b = rs.getString(k);
                            storemessage = b + "\t\t|\t\t";
                            System.out.print(b + "\t\t|\t\t");
                            terminate = terminate + storemessage;
                        }

                    }

                }
                stmt.close();
                rs.close();
            } catch (SQLException e) {
                String Exceptioninput = e.toString();
                String Exceptionremove = "java.sql.SQLSyntaxErrorException: ";
                String result = Exceptioninput.replaceAll(Exceptionremove, "");
                System.out.println(result);
                error = result; //+ "\nwrong input\nthe correct input is\nTable-name";

            }
            stmt = null;
        } else {
            String tableOne = tableCheck[0];
            String tablefix = textfix(tableOne);
            String indexColumnNamefix = textfix(indexColumnName);
            ResultSet rs;
            stmt = conn.createStatement();
            try {

                rs = stmt.executeQuery("select * from " + tablefix);
                ResultSetMetaData rsmd = rs.getMetaData();
                String checkType = rsmd.getColumnTypeName(1);
                if ("INTEGER".equals(checkType)) {
                    stmt.close();
                    stmt = null;
                    stmt = conn.createStatement();

                    int indexfix = 0;
                    try {
                        indexfix = Integer.parseInt(index);
                        throw new Exception("your first column type is int");

                    } catch (Exception e) {
                        error = "your first column type is int";
                    }
                    sql = "SELECT * FROM " + tablefix + " WHERE " + indexColumnNamefix + " = " + indexfix;
                    rs = stmt.executeQuery(sql);
                    // stmt.close();
                } else if ("VARCHAR".equals(checkType)) {
                    for (int i = 0; i < tableCheck.length; i++) {
                        if (i < tableCheck.length - 1) {
                            String tableTemp = tableCheck[i];
                            String tableTempfix = textfix(tableTemp);
                            String sqlTemp = "";
                            sqlTemp = "SELECT * FROM " + tableTempfix + " WHERE " + indexColumnNamefix + " = '" + index + "'" + " union ";
                            sql = sql + sqlTemp;
                            // System.out.println("IM here");
                        } else {
                            String tableTemp = tableCheck[i];
                            String tableTempfix = textfix(tableTemp);

                            String sqlTemp = "";
                            sqlTemp = "SELECT * FROM " + tableTempfix + " WHERE " + indexColumnNamefix + " = '" + index + "'";
                            sql = sql + sqlTemp;

                        }
                    }
                    stmt.close();
                    stmt = null;
                    stmt = conn.createStatement();
                    rs = stmt.executeQuery(sql);

                    //stmt.close();
                }
                int numberCols = rsmd.getColumnCount();
                int counting = 0;
                String CheckingContent = "";
                // System.out.println("IM here");
                while (rs.next()) {
                    for (int k = 1; k <= numberCols; k++) {
                        checkType = rsmd.getColumnTypeName(k);
                        //System.out.println(checkType);
                        if ("INTEGER".equals(checkType)) {
                            int a = rs.getInt(k);
                            storemessage = a + "\t\t|\t\t";
                            System.out.print(storemessage);

                            terminate = terminate + storemessage;
                        } else if ("VARCHAR".equals(checkType)) {
                            String checkColumnName = getTableColumnOnly(tableCheck[0]);
                            //System.out.println(checkColumnName);
                            String checkColumnArray[] = checkColumnName.split("|");
                            String importantMessage = checkColumnArray[0];
                            for (int i = 0; i < tableCheck.length; i++) {

                                // int count = 0;
                                if (i == 0) {
                                    String AllColumn = getTableColumnOnly(tableCheck[i]);
                                    String AllColumnSplit[] = AllColumn.split("|");
                                    for (int b = 0; i < AllColumnSplit.length; b++) {
                                        if (b < AllColumnSplit.length - 1) {
                                            String output = AllColumnSplit[b] + "      |";
                                            System.out.print(output);
                                        } else {
                                            String output = AllColumnSplit[b] + "      |";
                                            System.out.println(output);
                                        }

                                    }

                                } else {
                                    String AllColumn = getTableColumnOnly(tableCheck[i]);
                                    String AllColumnSplit[] = AllColumn.split("|");

                                    for (int b = 1; i < AllColumnSplit.length; b++) {
                                        if (b < AllColumnSplit.length - 1) {
                                            String output = AllColumnSplit[b] + "      |";
                                            System.out.print(output);
                                        } else {
                                            String output = AllColumnSplit[b] + "      |";
                                            System.out.println(output);
                                        }

                                    }
                                }

                                if (counting == 0) {
                                    CheckingContent = rs.getString(1);
                                    ResultSetMetaData rmd = rs.getMetaData();
                                    //   System.out.println(rmd.getColumnLabel(1));
                                    String outPut = rs.getString(k);
                                    storemessage = outPut + "\t\t|\t\t";
                                    System.out.print(outPut + "\t\t|\t\t");
                                    terminate = terminate + storemessage;
                                    counting++;
                                } else {

                                    String outPut = rs.getString(k);
                                    if (outPut.equals(CheckingContent)) {
                                        outPut = "";
                                    } else if (!"".equals(outPut)) {
                                        storemessage = outPut + "\t\t|\t\t";
                                        System.out.print(outPut + "\t\t|\t\t");
                                        terminate = terminate + storemessage;
                                        counting++;
                                    }

                                }
                            }

                        }

                    }
                    stmt.close();
                    rs.close();
                }
            } catch (SQLException e) {
                String Exceptioninput = e.toString();
                String Exceptionremove = "java.sql.SQLSyntaxErrorException: ";
                String result = Exceptioninput.replaceAll(Exceptionremove, "");
                System.out.println(result);
                error = result; //+ "\nwrong input\nthe correct input is\nTable-name";

            }
            stmt = null;

        }
//        stmt.close();
    }//this method is base on union may have column quantity problem
    
    /**Add Column to a table
     * the type is always varchar and the space is 100 varchar(100)
     *
     * @param table
     * @param ColumnName
     * @throws SQLException
     */
    public void addColumn(String table,String ColumnName) throws SQLException{
          reset(); 
        stmt = conn.createStatement();
        try {
            String tablefix=textfix(table);
            String ColumnNamefix=textfix(ColumnName);
            sql="alter table "+tablefix+" ADD "+ColumnNamefix+" VARCHAR(100) ";            
            // int a=0;
            // rs = stmt.executeQuery(sql);
            stmt.executeUpdate(sql);
            terminate = "execute success";
            stmt.close();
        } catch (SQLException e) {
            System.out.println(e);
            error = e.toString();
        }

        
    }
    
    /**Drop a column from a table
     *
     * @param table
     * @param ColumnName
     * @throws SQLException
     */
    public void removeColumn(String table,String ColumnName) throws SQLException{
        reset();
        stmt = conn.createStatement();
        try {
            String tablefix=textfix(table);
            String ColumnNamefix=textfix(ColumnName);
            sql="alter table "+tablefix+" DROP "+ColumnNamefix;            
            // int a=0;
            // rs = stmt.executeQuery(sql);
            stmt.executeUpdate(sql);
            terminate = "execute success";
            stmt.close();
        } catch (SQLException e) {
            System.out.println(e);
            error = e.toString();
        }

    }
    
    
    
      public String showIndexMax(String table,String index_colomn) {
        reset();
        try {

            String tablefix = textfix(table);
            String index_column_fix = textfix(index_colomn);
            stmt = conn.createStatement();
            sql = "SELECT MAX( "+index_column_fix+" ) as maxium FROM " + tablefix;
         //  System.out.println(sql);
            ResultSet results = stmt.executeQuery(sql);
          //   System.out.println(sql);
            ResultSetMetaData rsmd = results.getMetaData();
            while (results.next()) {
             //   System.out.println("1");
             terminate = results.getString("maxium");
              //  System.out.println(results.getString("maxium"));
            }
        //    System.out.println(rsmd.getColumnCount());
           // rsmd.getColumnLabel(0);
         
         //   System.out.println(a);
            results.close();
            stmt.close();

            //storemessage=null;
            //terminate=null;
        } catch (SQLException e) {

            String Exceptioninput = e.toString();
            String Exceptionremove = "java.sql.SQLSyntaxErrorException: ";
            String result = Exceptioninput.replaceAll(Exceptionremove, "");
            System.out.println(e.toString());
            error = result + "\nwrong input\nthe correct input is\nTable-name";
        }
        return terminate;

    }

}
